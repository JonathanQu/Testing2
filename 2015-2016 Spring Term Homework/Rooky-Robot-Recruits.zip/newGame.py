#!/usr/bin/python
print "content-type:text/html \n"
print '<!DOCTYPE html><html><head></head><body>'

print 'testing123'

print '</body></html>'
